-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Время создания: Янв 29 2018 г., 20:17
-- Версия сервера: 10.1.26-MariaDB
-- Версия PHP: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `construction`
--
CREATE DATABASE IF NOT EXISTS `construction` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `construction`;

-- --------------------------------------------------------

--
-- Структура таблицы `calculator`
--

DROP TABLE IF EXISTS `calculator`;
CREATE TABLE IF NOT EXISTS `calculator` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `price` float NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `calculator`
--

INSERT INTO `calculator` (`id`, `name`, `price`) VALUES
(1, 'Каркас', 13000),
(2, 'Газобетон', 15000),
(3, 'Брус', 11000),
(4, 'Свайный фундамент', 2000),
(5, 'Монолитный фундамент', 3500),
(6, 'Ленточный фундамент', 3700),
(7, 'Сайдинг', 400),
(8, 'Имитация бруса', 300),
(9, 'Имитация бревна', 700),
(10, 'Штукатурка', 1000),
(11, 'Металлочерепица', 500),
(12, 'Мягкая кровля', 250),
(13, 'Фальцевая кровля', 250),
(14, 'Вагонка', 500),
(15, 'Гипсокартон', 600),
(16, 'Система отопления', 1000),
(18, 'Канализация', 1000),
(19, 'Электроснабжение', 1000);

-- --------------------------------------------------------

--
-- Структура таблицы `callback`
--

DROP TABLE IF EXISTS `callback`;
CREATE TABLE IF NOT EXISTS `callback` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `phone` varchar(45) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `callback`
--

INSERT INTO `callback` (`id`, `name`, `phone`, `created_at`) VALUES
(1, 'Лена', '89110349611', '2018-01-15 17:40:42'),
(2, 'Ваня', '99110349511', '2018-01-15 18:30:49'),
(3, 'Антон', '89235679513', '2018-01-15 19:46:04'),
(4, 'Мария', '88124456677', '2018-01-15 19:46:18'),
(5, 'Геннадий', '89657865494', '2018-01-15 19:46:45'),
(6, 'Игорь', '89216785439', '2018-01-15 19:47:14'),
(7, 'Илья', '89456749999', '2018-01-15 19:47:30'),
(8, 'Фёкла', '+79456907878', '2018-01-15 19:47:59'),
(9, 'Женя', '+79065678435', '2018-01-15 19:49:52'),
(10, 'Марина', '89089705555', '2018-01-15 19:50:23'),
(11, 'Олег', '+79678580000', '2018-01-15 19:51:24'),
(12, 'Семён Фёдорович', '89657865646', '2018-01-15 19:52:41');

-- --------------------------------------------------------

--
-- Структура таблицы `feedback`
--

DROP TABLE IF EXISTS `feedback`;
CREATE TABLE IF NOT EXISTS `feedback` (
  `id_feedback` int(11) NOT NULL AUTO_INCREMENT,
  `text` longtext NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(30) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_feedback`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `feedback`
--

INSERT INTO `feedback` (`id_feedback`, `text`, `name`, `email`, `created_at`) VALUES
(1, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Елена', 'feklo4ka@gmail.com', '2018-01-16 18:13:22'),
(2, 'But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system, and expound the actual teachings of the great explorer of the truth, the master-builder of human happiness. No one rejects, dislikes, or avoids pleasure itself, because it is pleasure, but because those who do not know how to pursue pleasure rationally encounter consequences that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure. To take a trivial example, which of us ever undertakes laborious physical exercise, except to obtain some advantage from it? But who has any right to find fault with a man who chooses to enjoy a pleasure that has no annoying consequences, or one who avoids a pain that produces no resultant pleasure?', 'Иван', 'krasotun1111@mail.ru', '2018-01-16 18:21:23'),
(3, 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat', 'Олег', 'oleg@mail.ru', '2018-01-16 18:50:26'),
(4, 'On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire, that they cannot foresee the pain and trouble that are bound to ensue; and equal blame belongs to those who fail in their duty through weakness of will, which is the same as saying through shrinking from toil and pain. These cases are perfectly simple and easy to distinguish. In a free hour, when our power of choice is untrammelled and when nothing prevents our being able to do what we like best, every pleasure is to be welcomed and every pain avoided. But in certain circumstances and owing to the claims of duty or the obligations of business it will frequently occur that pleasures have to be repudiated and annoyances accepted. The wise man therefore always holds in these matters to this principle of selection: he rejects pleasures to secure other greater pleasures, or else he endures pains to avoid worse pains', 'Иванов Иван Иванович', 'ivanovich@yandex.ru', '2018-01-16 18:51:01'),
(5, 'On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire, that they cannot foresee the pain and trouble that are bound to ensue; and equal blame belongs to those who fail in their duty through weakness of will, which is the same as saying through shrinking from toil and pain. These cases are perfectly simple and easy to distinguish. In a free hour, when our power of choice is untrammelled and when nothing prevents our being able to do what we like best, every pleasure is to be welcomed and every pain avoided. But in certain circumstances and owing to the claims of duty or the obligations of business it will frequently occur that pleasures have to be repudiated and annoyances accepted. The wise man therefore always holds in these matters to this principle of selection: he rejects pleasures to secure other greater pleasures, or else he endures pains to avoid worse pains', 'Анна Петровна', 'anna@gmail.com', '2018-01-16 18:51:32'),
(6, 'On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire, that they cannot foresee the pain and trouble that are bound to ensue; and equal blame belongs to those who fail in their duty through weakness of will, which is the same as saying through shrinking from toil and pain. These cases are perfectly simple and easy to distinguish. In a free hour, when our power of choice is untrammelled and when nothing prevents our being able to do what we like best, every pleasure is to be welcomed and every pain avoided. But in certain circumstances and owing to the claims of duty or the obligations of business it will frequently occur that pleasures have to be repudiated and annoyances accepted. The wise man therefore always holds in these matters to this principle of selection: he rejects pleasures to secure other greater pleasures, or else he endures pains to avoid worse pains', 'Иннокентий', 'kesha@list.ru', '2018-01-16 18:51:52'),
(7, 'On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire, that they cannot foresee the pain and trouble that are bound to ensue; and equal blame belongs to those who fail in their duty through weakness of will, which is the same as saying through shrinking from toil and pain. These cases are perfectly simple and easy to distinguish. In a free hour, when our power of choice is untrammelled and when nothing prevents our being able to do what we like best, every pleasure is to be welcomed and every pain avoided. But in certain circumstances and owing to the claims of duty or the obligations of business it will frequently occur that pleasures have to be repudiated and annoyances accepted. The wise man therefore always holds in these matters to this principle of selection: he rejects pleasures to secure other greater pleasures, or else he endures pains to avoid worse pains', 'Гоша', 'goga111@gmail.com', '2018-01-16 18:52:18'),
(8, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Феоклист', '234567@mail.ru', '2018-01-16 18:53:06'),
(9, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Агриппина', 'grrrr@gmail.com', '2018-01-16 18:53:33');

-- --------------------------------------------------------

--
-- Структура таблицы `gallery`
--

DROP TABLE IF EXISTS `gallery`;
CREATE TABLE IF NOT EXISTS `gallery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `is_published` tinyint(4) DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `cover_img` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `gallery`
--

INSERT INTO `gallery` (`id`, `name`, `is_published`, `created_at`, `cover_img`) VALUES
(6, 'Дом со вторым светом', 1, '2018-01-22 17:08:37', 'projects/Дом со вторым светом/1.jpg'),
(7, 'Дом с бассейном', 1, '2018-01-22 17:22:02', 'projects/Дом с бассейном/2.jpg'),
(8, 'Дом на Истре', 1, '2018-01-22 17:26:08', 'projects/Дом на Истре/4.jpg'),
(9, 'Дом в Ушково', 1, '2018-01-22 17:27:37', 'projects/Дом в Ушково/1.jpg'),
(10, 'Дом в Сосново', 1, '2018-01-22 17:28:30', 'projects/Дом в Сосново/1.jpg'),
(11, 'Дом в Смолячково', 1, '2018-01-22 17:28:56', 'projects/Дом в Смолячково/1.jpg'),
(12, 'Дом в стиле хай-тек', 1, '2018-01-22 17:29:26', 'projects/Дом в стиле хай-тек/1.jpg'),
(13, 'Дом в Сестрорецке', 1, '2018-01-22 17:30:06', 'projects/Дом в Сестрорецке/1.jpg'),
(14, 'Дом в Репино', 1, '2018-01-22 17:30:36', 'projects/Дом в Репино/1.jpg'),
(15, 'Дом в Левашово', 1, '2018-01-22 17:31:08', 'projects/Дом в Левашово/1.jpg'),
(16, 'Дом в Лайкове', 1, '2018-01-22 17:31:35', 'projects/Дом в Лайкове/1.jpg');

-- --------------------------------------------------------

--
-- Структура таблицы `gallery_image`
--

DROP TABLE IF EXISTS `gallery_image`;
CREATE TABLE IF NOT EXISTS `gallery_image` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gallery_id` int(11) NOT NULL,
  `path` varchar(225) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_gallery_image_gallery_idx` (`gallery_id`)
) ENGINE=InnoDB AUTO_INCREMENT=129 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `gallery_image`
--

INSERT INTO `gallery_image` (`id`, `gallery_id`, `path`, `created_at`) VALUES
(38, 6, 'projects/Дом со вторым светом/2.jpg', '2018-01-22 17:11:34'),
(39, 6, 'projects/Дом со вторым светом/3.jpg', '2018-01-22 17:11:34'),
(40, 6, 'projects/Дом со вторым светом/4.jpg', '2018-01-22 17:11:34'),
(41, 6, 'projects/Дом со вторым светом/5.jpg', '2018-01-22 17:11:34'),
(42, 6, 'projects/Дом со вторым светом/6.jpg', '2018-01-22 17:11:34'),
(43, 6, 'projects/Дом со вторым светом/7.jpg', '2018-01-22 17:11:34'),
(44, 6, 'projects/Дом со вторым светом/8.jpg', '2018-01-22 17:11:34'),
(45, 6, 'projects/Дом со вторым светом/9.jpg', '2018-01-22 17:11:34'),
(46, 6, 'projects/Дом со вторым светом/10.jpg', '2018-01-22 17:11:34'),
(47, 6, 'projects/Дом со вторым светом/11.jpg', '2018-01-22 17:11:34'),
(48, 6, 'projects/Дом со вторым светом/12.jpg', '2018-01-22 17:11:34'),
(49, 6, 'projects/Дом со вторым светом/13.jpg', '2018-01-22 17:11:34'),
(59, 7, 'projects/Дом с бассейном/1.jpg', '2018-01-22 17:24:52'),
(60, 7, 'projects/Дом с бассейном/4.jpg', '2018-01-22 17:24:52'),
(61, 7, 'projects/Дом с бассейном/5.jpg', '2018-01-22 17:24:52'),
(62, 7, 'projects/Дом с бассейном/6.jpg', '2018-01-22 17:24:53'),
(63, 7, 'projects/Дом с бассейном/7.jpg', '2018-01-22 17:24:53'),
(64, 7, 'projects/Дом с бассейном/8.jpg', '2018-01-22 17:24:53'),
(65, 7, 'projects/Дом с бассейном/9.jpg', '2018-01-22 17:24:53'),
(66, 7, 'projects/Дом с бассейном/10.jpg', '2018-01-22 17:24:53'),
(67, 7, 'projects/Дом с бассейном/11.jpg', '2018-01-22 17:24:53'),
(68, 8, 'projects/Дом на Истре/1.jpg', '2018-01-22 17:26:08'),
(69, 8, 'projects/Дом на Истре/2.jpg', '2018-01-22 17:26:08'),
(70, 8, 'projects/Дом на Истре/3.jpg', '2018-01-22 17:26:08'),
(71, 8, 'projects/Дом на Истре/5.jpg', '2018-01-22 17:26:09'),
(72, 8, 'projects/Дом на Истре/6.jpg', '2018-01-22 17:26:09'),
(73, 8, 'projects/Дом на Истре/7.jpg', '2018-01-22 17:26:09'),
(74, 8, 'projects/Дом на Истре/8.jpg', '2018-01-22 17:26:09'),
(75, 8, 'projects/Дом на Истре/9.jpg', '2018-01-22 17:26:09'),
(76, 9, 'projects/Дом в Ушково/2.jpg', '2018-01-22 17:27:37'),
(77, 9, 'projects/Дом в Ушково/3.jpg', '2018-01-22 17:27:37'),
(78, 9, 'projects/Дом в Ушково/4.jpg', '2018-01-22 17:27:37'),
(79, 9, 'projects/Дом в Ушково/5.jpg', '2018-01-22 17:27:37'),
(80, 9, 'projects/Дом в Ушково/6.jpg', '2018-01-22 17:27:37'),
(81, 9, 'projects/Дом в Ушково/7.jpg', '2018-01-22 17:27:38'),
(82, 9, 'projects/Дом в Ушково/8.jpg', '2018-01-22 17:27:38'),
(83, 9, 'projects/Дом в Ушково/9.jpg', '2018-01-22 17:27:38'),
(84, 9, 'projects/Дом в Ушково/10.jpg', '2018-01-22 17:27:38'),
(85, 12, 'projects/Дом в стиле хай-тек/2.jpg', '2018-01-22 17:29:26'),
(86, 12, 'projects/Дом в стиле хай-тек/3.jpg', '2018-01-22 17:29:26'),
(87, 12, 'projects/Дом в стиле хай-тек/4.jpg', '2018-01-22 17:29:26'),
(88, 12, 'projects/Дом в стиле хай-тек/5.jpg', '2018-01-22 17:29:27'),
(89, 12, 'projects/Дом в стиле хай-тек/6.jpg', '2018-01-22 17:29:27'),
(90, 12, 'projects/Дом в стиле хай-тек/7.jpg', '2018-01-22 17:29:27'),
(91, 12, 'projects/Дом в стиле хай-тек/8.jpg', '2018-01-22 17:29:27'),
(92, 12, 'projects/Дом в стиле хай-тек/9.jpg', '2018-01-22 17:29:27'),
(93, 12, 'projects/Дом в стиле хай-тек/10.jpg', '2018-01-22 17:29:27'),
(94, 13, 'projects/Дом в Сестрорецке/2.jpg', '2018-01-22 17:30:07'),
(95, 13, 'projects/Дом в Сестрорецке/3.jpg', '2018-01-22 17:30:07'),
(96, 13, 'projects/Дом в Сестрорецке/4.jpg', '2018-01-22 17:30:07'),
(97, 13, 'projects/Дом в Сестрорецке/5.jpg', '2018-01-22 17:30:07'),
(98, 13, 'projects/Дом в Сестрорецке/6.jpg', '2018-01-22 17:30:07'),
(99, 13, 'projects/Дом в Сестрорецке/7.jpg', '2018-01-22 17:30:07'),
(100, 13, 'projects/Дом в Сестрорецке/8.jpg', '2018-01-22 17:30:07'),
(101, 13, 'projects/Дом в Сестрорецке/9.jpg', '2018-01-22 17:30:07'),
(102, 13, 'projects/Дом в Сестрорецке/10.jpg', '2018-01-22 17:30:07'),
(103, 13, 'projects/Дом в Сестрорецке/11.jpg', '2018-01-22 17:30:07'),
(104, 14, 'projects/Дом в Репино/2.jpg', '2018-01-22 17:30:36'),
(105, 14, 'projects/Дом в Репино/3.jpg', '2018-01-22 17:30:36'),
(106, 14, 'projects/Дом в Репино/4.jpg', '2018-01-22 17:30:36'),
(107, 14, 'projects/Дом в Репино/5.jpg', '2018-01-22 17:30:36'),
(108, 14, 'projects/Дом в Репино/6.jpg', '2018-01-22 17:30:36'),
(109, 14, 'projects/Дом в Репино/7.jpg', '2018-01-22 17:30:36'),
(110, 14, 'projects/Дом в Репино/8.jpg', '2018-01-22 17:30:36'),
(111, 14, 'projects/Дом в Репино/9.jpg', '2018-01-22 17:30:36'),
(112, 14, 'projects/Дом в Репино/10.jpg', '2018-01-22 17:30:36'),
(113, 15, 'projects/Дом в Левашово/2.jpg', '2018-01-22 17:31:08'),
(114, 15, 'projects/Дом в Левашово/3.jpg', '2018-01-22 17:31:08'),
(115, 15, 'projects/Дом в Левашово/4.jpg', '2018-01-22 17:31:08'),
(116, 15, 'projects/Дом в Левашово/5.jpg', '2018-01-22 17:31:08'),
(117, 15, 'projects/Дом в Левашово/6.jpg', '2018-01-22 17:31:08'),
(118, 15, 'projects/Дом в Левашово/7.jpg', '2018-01-22 17:31:08'),
(119, 15, 'projects/Дом в Левашово/9.jpg', '2018-01-22 17:31:08'),
(120, 15, 'projects/Дом в Левашово/10.jpg', '2018-01-22 17:31:08'),
(121, 15, 'projects/Дом в Левашово/11.jpg', '2018-01-22 17:31:08'),
(122, 15, 'projects/Дом в Левашово/12.jpg', '2018-01-22 17:31:09'),
(123, 15, 'projects/Дом в Левашово/13.jpg', '2018-01-22 17:31:09'),
(124, 15, 'projects/Дом в Левашово/14.jpg', '2018-01-22 17:31:09'),
(125, 15, 'projects/Дом в Левашово/15.jpg', '2018-01-22 17:31:09'),
(126, 16, 'projects/Дом в Лайкове/2.jpg', '2018-01-22 17:31:35'),
(127, 16, 'projects/Дом в Лайкове/3.jpg', '2018-01-22 17:31:35'),
(128, 16, 'projects/Дом в Лайкове/4.jpg', '2018-01-22 17:31:36');

-- --------------------------------------------------------

--
-- Структура таблицы `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `password` varchar(45) NOT NULL,
  `login` varchar(255) NOT NULL,
  `session` varchar(255) DEFAULT NULL,
  `token` varchar(45) DEFAULT NULL,
  `expire` datetime DEFAULT NULL,
  PRIMARY KEY (`login`),
  UNIQUE KEY `session_UNIQUE` (`session`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `user`
--

INSERT INTO `user` (`password`, `login`, `session`, `token`, `expire`) VALUES
('b59c67bf196a4758191e42f76670ceba', 'admin', '7q40osevv823f6ljnr65d278qh', '8gsvn5qnew8c5w9v08eqcop04tf9ftss', '2018-01-29 00:16:59');

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `gallery_image`
--
ALTER TABLE `gallery_image`
  ADD CONSTRAINT `fk_gallery_image_gallery` FOREIGN KEY (`gallery_id`) REFERENCES `gallery` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
